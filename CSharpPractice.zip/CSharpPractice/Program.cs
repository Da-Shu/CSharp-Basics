﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpPractice
{
    class Program
    {
        static void Main(string[] args)
        {
            var speedLimit = 65;
            Console.WriteLine("Please enter car's speed.");

            var carSpeed = Convert.ToInt32(Console.ReadLine());
            var demerit = (carSpeed - speedLimit) / 5;

            if (carSpeed < speedLimit)
            {
                Console.WriteLine("OK");
            }
            else
            {
                Console.WriteLine(string.Format("Slow down! You've received: {0} demerits!", demerit));
            }

            if(demerit > 12)
            {
                Console.WriteLine("License Suspended");
            }
        }
    }
}
