﻿namespace WarriorGame.Enum

{
    enum Faction
    {
        GoodGuy,
        BadGuy
    }
}
