﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArraysAndListsExercises
{
    class Program
    {
        static void Main(string[] args)
        {
            //Exercise 5
            string[] elements;
            while (true)
            {
                Console.WriteLine("Please enter a list of numbers, separated by a ',':");
                var input = Console.ReadLine().Split(',');

                if (input.Length < 5 || input == null)
                {
                    Console.WriteLine("Invalid list");
                    continue;
                }
                elements = input;
                break;
            }

            var numbers = new List<int>();
            foreach (var number in elements)
                numbers.Add(Convert.ToInt32(number));

            var smallest = new List<int>();
            while (smallest.Count < 3)
            {
                var min = numbers[0];
                foreach (var number in numbers)
                {
                    if (number < min)
                        min = number;
                }
                smallest.Add(min);

                numbers.Remove(min);
            }
            Console.WriteLine("The smallest three numbers you entered are: ");
            foreach(var number in smallest)
                Console.WriteLine(number);
        }
    }

    //Exercise 4

//      var numbers = new List<int>();

//            while (true)
//            {
//                Console.WriteLine("Please enter a number or type 'quit' to exit: ");
//                var input = Console.ReadLine();

//                if (input.ToLower() == "quit")
//                    break;

//                numbers.Add(Convert.ToInt32(input));
//            }

//      var uniqueNum = new List<int>();
//            foreach (var num in numbers)
//            {
//                if (!uniqueNum.Contains(num))
//                    uniqueNum.Add(num);
//            }
//            Console.WriteLine("The unique numbers you entered are: ");
//            foreach (var num in uniqueNum)
//                Console.WriteLine(num);


    //Exercise 3


    //var numbers = new List<int>();
    //while (numbers.Count < 5)
    //{
    //    Console.WriteLine("Please enter a (unique) number: ");
    //    var input = Convert.ToInt32(Console.ReadLine());
    //    if (numbers.Contains(input))
    //    {
    //        Console.WriteLine("You have already entered " + input);
    //        continue;
    //    }
    //    numbers.Add(input);
    //}
    //numbers.Sort();

    //Console.WriteLine("The list of numbers you entered is:");

    //foreach (var number in numbers)
    //    Console.WriteLine(number);


    //Exercise 2


    //    Console.WriteLine("Please enter a name: ");
    //    var name = Console.ReadLine();

    //    var array = new char[name.Length];
    //    for (var i = name.Length; i > 0; i--)
    //        array[name.Length - i] = name[i - 1];

    //    var reversed = new string(array);
    //    Console.WriteLine("Reversed name is : " + reversed);

    //var names = new List<string>();


    //Exercise 1


    //while (true)
    //{
    //    Console.WriteLine("Please enter a new name and press 'ENTER'.  Press 'ENTER' without adding a name to exit.");

    //    var input = Console.ReadLine();
    //    if (String.IsNullOrWhiteSpace(input))
    //        break;
    //    names.Add(input);
    //}

    //if (names.Count == 1)
    //    Console.WriteLine("{0} likes your post!", names[0]);

    //else if (names.Count == 2)
    //    Console.WriteLine("{0} and {1} like your post!", names[0], names[1]);


    //else if (names.Count > 2)
    //    Console.WriteLine("{0} , {1}, and {2} other(s) like your post!", names[0], names[1], names.Count -2);


    //else
    //    Console.WriteLine("nobody likes you, or your post.");
}

