﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WorkingWithTextExercises
{
    class Program
    {
        static void Main(string[] args)
        {
            //EXERCISE 5
            //Console.WriteLine("Please enter an English word:");
            //var input = Console.ReadLine();

            //var vowelList = "a, e, i, o, u";
            //var inputVowels = "";
            //var vowelCount = 0;
            //foreach (var letter in input.ToLower())
            //{
            //    if (vowelList.Contains(letter))
            //        inputVowels += letter;
            //}
            //Console.WriteLine(inputVowels.Length);

            //OR (NEEDS LESS MEMORY)

            Console.WriteLine("Please enter an English word: ");
            var input = Console.ReadLine().ToLower();


            Console.WriteLine(VowelCounter(input));
        }

        public static int VowelCounter(string input)
        {
            var vowels = new List<char>(new char[] { 'a', 'e', 'i', 'o', 'u' });//var vowels = "aeiou" also works
            var vowelCount = 0;
            foreach (var letter in input)
            {
                if (vowels.Contains(letter))
                    vowelCount++;
            }
            return vowelCount;
        }
    //EXERCISE 4
    //Console.WriteLine("Enter a few words separated by a space");
    //    var input = Console.ReadLine();

    //    if (String.IsNullOrWhiteSpace(input))
    //    {
    //        Console.WriteLine("Error");
    //        return;
    //    }

    //    try
    //    {
    //        var variableName = "";
    //        foreach (var word in input.Split(' '))
    //        {
    //            var wordWithPascalCase = char.ToUpper(word[0]) + word.ToLower().Substring(1);
    //            variableName += wordWithPascalCase;
    //        }
    //        Console.WriteLine(variableName);
    //    }
    //    catch(Exception)
    //    {
    //        Console.WriteLine("Did you enter an extra space?");
    //    }           

    //EXERCISE 3

    //Console.WriteLine("Please enter a time value in 24 hour format (eg. 19:00): ");
    //var input = Console.ReadLine();

    //if (String.IsNullOrWhiteSpace(input))
    //{
    //    Console.WriteLine("Invalid Number");
    //    return;
    //}

    //var components = input.Split(':');
    //if (components.Length != 2)
    //{
    //    Console.WriteLine("Invalid Number");
    //    return;
    //}

    //try
    //{
    //    var hour = Convert.ToInt32(components[0]);
    //    var minute = Convert.ToInt32(components[1]);

    //    if (hour >= 0 && hour <= 23 && minute >= 0 && minute <=59)
    //        Console.WriteLine("Thanks for entereing a valid time");
    //    else
    //        Console.WriteLine("Invalid Time");
    //}
    //catch (Exception)
    //{
    //    Console.WriteLine("Invalid Time");
    //}


    //EXERCISE 2
    //Console.WriteLine("Enter a few numbers separated by a hyphen:");
    //var input = Console.ReadLine();

    //if (String.IsNullOrWhiteSpace(input))
    //    return;

    //var numbers = new List<int>();
    //foreach (var number in input.Split('-'))
    //    numbers.Add(Convert.ToInt32(number));

    //var uniques = new List<int>();
    //var includesDuplicates = false;
    //foreach (var number in numbers)
    //    if (!uniques.Contains(number))
    //        uniques.Add(number);
    //    else
    //    {
    //        includesDuplicates = true;
    //        break;
    //    }

    //if (includesDuplicates)
    //    Console.WriteLine("Duplicates");

    //Exercise 1 ALTERNATE (MOSH'S WAY)

    //    Console.WriteLine("Enter a few numbers separated by hyphens");
    //    var input = Console.ReadLine();

    //    var numbers = new List<int>();
    //    foreach (var number in input.Split('-'))
    //        numbers.Add(Convert.ToInt32(number));

    //    var uniques = new List<int>();
    //    var includesDuplicates = false;
    //    foreach(var number in numbers)
    //    {
    //        if (!uniques.Contains(number))
    //            uniques.Add(number);
    //        else
    //        {
    //            includesDuplicates = true;
    //            break;
    //        }
    //    }
    //    if(includesDuplicates)
    //        Console.WriteLine("Contains Duplicates");
    //    else
    //        Console.WriteLine("No Duplicates");
    //}

    //************Exercise 1

    //    Console.WriteLine("Please enter a serires of numbers separated by hyphens:");
    //    var input = Console.ReadLine();

    //    var numbers = new List<int>();
    //    foreach (var number in input.Split('-'))
    //        numbers.Add(Convert.ToInt32(number));

    //    numbers.Sort();

    //    var isConsecutive = true;
    //    for (var i = 1; i < numbers.Count; i++)
    //    {
    //        if (numbers[i] != numbers[i-1] +1)
    //        {
    //            isConsecutive = false;
    //            break;
    //        }
    //    }

    //    var message = isConsecutive ? "Consecutive" : "Not Consecutive";
    //    Console.WriteLine(message);
    //}
}
}
