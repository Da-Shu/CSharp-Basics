﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace FilePathExercises
{
    class Program
    {
        static void Main(string[] args)
        {
            //EXERCISE 2

            var fileInfo = File.ReadAllText(@"c:\users\public\test.txt").Split(' ');

            var longestWord = fileInfo[0];
            foreach (var word in fileInfo)
            {
                if (word.Length > longestWord.Length)
                    longestWord = word;
            }

            Console.WriteLine(longestWord);
        }
    }
    //EXERCISE 1

    //var count = 0;

    //var fileInfo = File.ReadAllText(@"c:\users\public\test.txt").Split(' ');
    //foreach (var word in fileInfo)
    //{
    //    count++;
    //}

    //Console.WriteLine(count);
}
