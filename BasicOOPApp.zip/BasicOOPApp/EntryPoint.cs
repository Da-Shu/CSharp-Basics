﻿using BasicOOPApp;
using System;

class EntryPoint
{
    static void Main()
    {
        User user = new User("Dan", Race.Earthling);
        User userTwo = new User("Jon", Race.Marsian);
        User userThree = new User("Jeff", Race.Marsian);

        user.Password = 4;

        //
        user.ChangeNameColor();
        System.Console.WriteLine("The user race is " + user.race);
        System.Console.WriteLine("The user ID is " + user.ID);

        System.Console.WriteLine("**********");

        Utilities.ColorfulWriteLine(userTwo.Username, ConsoleColor.Green);
        System.Console.WriteLine("The user race is " + userTwo.race);
        System.Console.WriteLine("The user ID is " + userTwo.ID);

        System.Console.WriteLine("**********");

         Utilities.ColorfulWriteLine(userThree.Username, ConsoleColor.Green);
        System.Console.WriteLine("The user race is " + userThree.race);
        System.Console.WriteLine("The user ID is " + userThree.ID);


    }
}