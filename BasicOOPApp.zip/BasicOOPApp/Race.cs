﻿enum Race
{
    Earthling,
    Marsian
}
