﻿
namespace BasicOOPApp
{
    class User
    {

        //A const must be given a value immediately. 
        //public const int HEIGHT = 180;

        public readonly int HEIGHT;

        //The name is all CAPS because it's a constant (readonly) which should be all caps and separated by _)
        //readonly is a const that receives its value at runtime. 
        public readonly int ID;

        public static int currentID;

        //Connected to the enum Race
        public Race race; 

        private string username;
        private int password;

        public string Username
        {
            get
            {
                return "The username is " + username;
            }
        }

        public int Password
        {
            set
            {
                if (value >= 4 && value <= 10)
                {
                    password = value;
                }
                else
                {
                    System.Console.WriteLine("Oops, this is not a valid password.  Please use a password that is between 4-10.");
                }
            }
        }

        public User()
        {
            currentID++;
            ID = currentID;
        }

        public User(string username, Race race)
        {
            currentID++;
            ID = currentID;
            this.username = username;
            this.race = race;

            if (this.race == Race.Marsian)
            {
                HEIGHT = 100;
            }
            else if (this.race == Race.Earthling)
            {
                HEIGHT = 180;
            }
            race = Race.Marsian;
        }

        public void ChangeNameColor()
        {
            Utilities.ColorfulWriteLine(this.username, System.ConsoleColor.Green);
        }
    }
}
