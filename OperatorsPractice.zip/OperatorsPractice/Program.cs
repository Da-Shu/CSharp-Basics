﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OperatorsPractice
{
    class Program
    {
        static void Main(string[] args)
        {
            var a = 10;
            var b = 3;

            //MUST CAST TO FLOAT TO GET REMAINDER
            Console.WriteLine((float)a / (float)b);
        }
    }
}
