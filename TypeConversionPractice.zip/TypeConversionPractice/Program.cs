﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TypeConversionPractice
{
    class Program
    {
        static void Main(string[] args)
        {
            //byte b = 1;
            //int i = b;

            //int i = 232;
            //byte b = (byte)i;

            try
            {
                var number = "1234";
                byte b = Convert.ToByte(number);
                Console.WriteLine(b);
            }
            catch (Exception)
            {
                Console.WriteLine("The number could not be convereted to byte.");
            }
        }
    }
}
