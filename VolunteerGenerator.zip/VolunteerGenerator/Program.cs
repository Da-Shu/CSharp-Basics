﻿using System;
using System.Collections.Generic;



namespace VolunteerGenerator
{
    class Program
    {
        static void Main(string[] args)
        {
            var random = new Random();
            var nameList = new List<string> { "James", "Marco", "Clay", "Joshua", "Nikee", "Christopher C", "Milan", "Joelle", "Levi", "Jonathan K", "Jacqueline", "Freddy", "Miguel", "Jerry", "Johnathan R", "Christopher F", "Chase", "William", "Daniel", "Nicholas" };

            try
            {
                while (true)
                {
                    var nameIndex = random.Next(nameList.Count);
                    var voluntold = nameList[nameIndex];

                    Console.WriteLine("Press ENTER to select a new VOLUNTEER or SPACE to quit");
                    var input = Console.ReadKey();

                    if (input.Key == ConsoleKey.Enter)
                    {
                        Console.WriteLine(voluntold);
                        nameList.Remove(voluntold);
                    }

                    else if (input.Key == ConsoleKey.Spacebar)
                        return;
                    else
                        Console.WriteLine("?.....YOUR OPTIONS WERE <ENTER> OR <SPACE>... Pay attention!");
                    continue;
                }
            }
            catch (Exception)
            {
                Console.WriteLine("Looks like you're out of names");
            }
        }
    }
}
