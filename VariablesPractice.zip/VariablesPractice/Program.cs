﻿using System;

namespace VariablesPractice
{
    class Program
    {
        static void Main(string[] args)
        {
            //ALL DATA TYPES CAN BE CHANGED TO VAR

            byte number = 2;
            int count = 10;
            float totalPrice = 20.95f;
            char character = 'A';
            string firstName = "Dan";
            bool isWorking = false;

            Console.WriteLine(number);
            Console.WriteLine(count);
            Console.WriteLine(totalPrice);
            Console.WriteLine(character);
            Console.WriteLine(firstName);
            Console.WriteLine(isWorking);
        }
    }
}
