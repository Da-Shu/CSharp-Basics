﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Iteration
{
    class Program
    {
        static void Main(string[] args)
        {
            ////////////////////////////////////////////////
            //********************************** WHILE LOOP WITH BREAK; AND CONTINUE;
            //while (true)
            //{
            //    Console.WriteLine("Type your name: ");
            //    var input = Console.ReadLine();

            //    if (!String.IsNullOrWhiteSpace(input))
            //    {
            //        Console.WriteLine("@Echo: " + input);
            //        continue;
            //    }
            //    break;
            //}



            /////////////////////////////////////////////////
            //********************************* FOREACH LOOPS
            //var name = "John Smith";

            ////for (var i = 0; i < name.Length; i++)
            ////{
            ////    Console.WriteLine(name[i]);
            ////}

            //foreach (var character in name)
            //{
            //    Console.WriteLine(character);
            //}

            //var numbers = new int[] { 1, 2, 3 };

            //foreach (int number in numbers)
            //{
            //    Console.WriteLine(number);
            //}



            ////////////////////////////////////////////
            //******************************** FOR LOOPS
            //for (var i = 0; i <= 10; i++)
            //{
            //    if (i%2 == 0)
            //    {
            //        Console.WriteLine(i);
            //    }
            //}

            //for (var i = 10; i >= 1; i--)
            //{
            //    if (i%2 == 0)
            //    {
            //        Console.WriteLine(i);
            //    }
            //}
        }
    }
}
