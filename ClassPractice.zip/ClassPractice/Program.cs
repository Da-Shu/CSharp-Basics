﻿

namespace ClassPractice
{
    class Program
    {
        static void Main(string[] args)
        {

        }
    }
}
